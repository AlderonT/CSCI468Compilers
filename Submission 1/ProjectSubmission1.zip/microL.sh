arg1=$1

wine ./SmallC.exe $arg1